#ifndef _LENA128_H
#define _LENA128_H

extern unsigned char lena128[];

#endif
