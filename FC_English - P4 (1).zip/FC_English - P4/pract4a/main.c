#include "trafo.h"
#include "types.h"
#include "lena128.h"

pixelRGB RGBImage[N][M];
unsigned char grayImage[N][M];
unsigned char binaryImage[N][M];
unsigned char whitesPerRow[N];

void initRGB(pixelRGB m[N][M]) {
    int i,j;

    for (i=0;i<N;i++)
        for (j=0; j<M; j++) {
            m[i][j].R = lena128[(i*M + j)*3];
            m[i][j].G = lena128[(i*M + j)*3 + 1];
            m[i][j].B = lena128[(i*M + j)*3 + 2];
        }
}

int main(void) {

	// 1. Create an NxM matrix from the array lena128
	initRGB(RGBImage);

	// 2. Transform the RGB matrix into a grayscale matrix
	RGB2GrayMatrix(RGBImage,grayImage);

	// 3. Transform the grayscale matrix into B&W
	gray2BinaryMatrix(grayImage,binaryImage);

	// 4. Count the white pixels in each row of binaryImage
	countWhites(binaryImage,whitesPerRow);


    return 0;
}
