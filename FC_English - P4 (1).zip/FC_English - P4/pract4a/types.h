#ifndef _TYPES_H
#define _TYPES_H

#define N 128
#define M 128

typedef struct _pixel_RGB_t {
	unsigned char R;
	unsigned char G;
	unsigned char B;
} pixelRGB;

#endif
